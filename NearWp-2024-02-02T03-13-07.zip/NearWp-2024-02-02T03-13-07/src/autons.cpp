#include "vex.h"



void default_constants(){
    chassis.set_drive_constants(10, 1.5, 0, 10, 0);
    chassis.set_heading_constants(6, .4, 0, 1, 0);
    chassis.set_turn_constants(12, .4, .03, 3, 15);
    chassis.set_swing_constants(12, .3, .001, 2, 15);
    chassis.set_drive_exit_conditions(1.5, 300, 5000);
    chassis.set_turn_exit_conditions(1, 300, 3000);
    chassis.set_swing_exit_conditions(1, 300, 3000);
}

void NearSideWpt()
{
  chassis.drive_distance(20);
  // chassis.turn_to_angle(90);
  // chassis.turn_to_angle(270);
  // chassis.turn_to_angle(25);
  // chassis.drive_distance(-10);
  // chassis.turn_to_angle(0);
  // Intake.spin(reverse);
  // chassis.drive_distance(-12);
  // chassis.drive_distance(12);
  // chassis.turn_to_angle(25);
  // FlapJacks.set(true);
  // chassis.drive_distance(-12);
  // FlapJacks.set(false);
  // chassis.turn_to_angle(270);
  // chassis.drive_distance(27);

}

void FarSideWpt()
{

}

void NearSideElims()
{
 chassis.drive_distance(6);
 chassis.drive_distance(12);
 chassis.drive_distance(18);
 chassis.drive_distance(-36);


}

void FarSideElims()
{
   chassis.drive_distance(10);
   chassis.drive_distance(20);
   chassis.drive_distance(30);
  // Intake.spin(fwd);
  // chassis.drive_distance(-5); 
  // Intake.stop();
  // chassis.drive_distance(25);
  // chassis.turn_to_angle(275);
  // FlapJacks.set(true);
  // chassis.drive_distance(10);
  // chassis.turn_to_angle(270);
  // chassis.turn_to_angle(275);
  // FlapJacks.set(false);
  // chassis.drive_distance(10);
  // chassis.drive_distance(-7);
  // chassis.turn_to_angle(90);
  // Intake.spin(reverse);
  // wait(5, msec);
  // chassis.drive_distance(-8);
  // Intake.stop();
  // chassis.drive_distance(-5);
  // chassis.turn_to_angle(0);
  // chassis.drive_distance(-15);
  // chassis.turn_to_angle(15);
  // Intake.spin(fwd);
  // chassis.drive_distance(-20);
  // Intake.stop();
  // chassis.drive_distance(6);
  // chassis.turn_to_angle(105);
  // Intake.spin(reverse);
  // wait(5, msec);
  // Intake.stop();
  // chassis.turn_to_angle(45);
  // Intake.spin(fwd);
  // chassis.drive_distance(-18);
  // chassis.turn_to_angle(0);
  // Intake.stop();
  // FlapJacks.set(true);
  // chassis.drive_distance(25);
  // chassis.drive_distance(-9);
  // FlapJacks.set(false);
  // chassis.turn_to_angle(180);
  // Intake.spin(reverse);
  // chassis.drive_distance(-11);
  // wait(5,msec);
  // chassis.drive_distance(15);



}

void Skills()
{
  
}

void NoAuton()
{
  //Leave Blank
}

