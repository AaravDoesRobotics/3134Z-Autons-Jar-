#include "vex.h"

using namespace vex;
using signature = vision::signature;
using code = vision::code;

// A global instance of brain used for printing to the V5 Brain screen
brain  Brain;

void HangMech()
{
  digital_out Hang = digital_out(Brain.ThreeWirePort.B);
  if(Hang.value())
    {
      Hang.set(false); 
      wait(200,msec); 
    }
    else 
    {
      Hang.set(true); 
      wait(200,msec);
    }
}

void ToggleFlapJacks() //Toggle Function for Flapjacks 
  {
    digital_out FlapJacks = digital_out(Brain.ThreeWirePort.A);
    if(FlapJacks.value())
    {
      FlapJacks.set(false); 
      wait(200,msec); 
    }
    else 
    {
      FlapJacks.set(true); 
      wait(200,msec);
    }
  }

 

  

  
// VEXcode device constructors

// VEXcode generated functions
// define variable for remote controller enable/disable

/**
 * Used to initialize code/tasks/devices added using tools in VEXcode Pro.
 * 
 * This should be called at the start of your int main function.
 */
void vexcodeInit( void ) {
  // nothing to initialize
}