#pragma once
#include "JAR-Template/drive.h"

class Drive;

extern Drive chassis;

void default_constants();

void NearSideWpt();
void FarSideWpt();
void NearSideElims();
void FarSideElims();
void NoAuton();
void Skills();
